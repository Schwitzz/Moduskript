<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN" sourcelanguage="en_US">
<context>
    <name>BulkInfoManager</name>
    <message>
        <location filename="../manuskript/ui/bulkInfoManager.py" line="69"/>
        <source>Form</source>
        <translation type="unfinished">表格</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/bulkInfoManager.py" line="70"/>
        <source>Affected Characters:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../manuskript/ui/bulkInfoManager.py" line="71"/>
        <source>NONE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../manuskript/ui/bulkInfoManager.py" line="72"/>
        <source>Add entry to the list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../manuskript/ui/bulkInfoManager.py" line="73"/>
        <source>Remove entry from the list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../manuskript/ui/bulkInfoManager.py" line="74"/>
        <source>Adds all items to the selected characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../manuskript/ui/bulkInfoManager.py" line="75"/>
        <source>Apply Changes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExportersManager</name>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.py" line="165"/>
        <source>Manage Exporters</source>
        <translation>管理导出</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.py" line="169"/>
        <source>Manuskript</source>
        <translation>Manuskript</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.py" line="171"/>
        <source>Description</source>
        <translation>描述</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.py" line="172"/>
        <source>Offers export to</source>
        <translation>提供导出到</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.py" line="173"/>
        <source>Status</source>
        <translation>状态</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.py" line="174"/>
        <source>Status:</source>
        <translation>状态：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.py" line="175"/>
        <source>Version:</source>
        <translation>版本：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.py" line="176"/>
        <source>Path:</source>
        <translation>路径：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.py" line="177"/>
        <source>...</source>
        <translation>…</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.py" line="178"/>
        <source>{HelpText}</source>
        <translation>{帮助文本}</translation>
    </message>
</context>
<context>
    <name>FrequencyAnalyzer</name>
    <message>
        <location filename="../manuskript/ui/tools/frequency_ui.py" line="107"/>
        <source>Frequency Analyzer</source>
        <translation>频谱</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequency_ui.py" line="112"/>
        <source>Word frequency</source>
        <translation>词频</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequency_ui.py" line="108"/>
        <source>Settings</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequency_ui.py" line="109"/>
        <source>Minimum size:</source>
        <translation>最短：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequency_ui.py" line="110"/>
        <source>Exclude words (comma separated):</source>
        <translation>排除词（逗号分隔）：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequency_ui.py" line="115"/>
        <source>Analyze</source>
        <translation>分析</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequency_ui.py" line="116"/>
        <source>Phrase frequency</source>
        <translation>词组频</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequency_ui.py" line="113"/>
        <source>Number of words: from</source>
        <translation>词数：从</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequency_ui.py" line="114"/>
        <source>to</source>
        <translation>到</translation>
    </message>
</context>
<context>
    <name>GenericListDialog</name>
    <message>
        <location filename="../manuskript/ui/listDialog_ui.py" line="43"/>
        <source>Title</source>
        <translation>标题</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/listDialog_ui.py" line="44"/>
        <source>Text</source>
        <translation>文本</translation>
    </message>
</context>
<context>
    <name>ImageTooltip.manager</name>
    <message>
        <location filename="../manuskript/ui/views/MDEditView.py" line="619"/>
        <source>The image path or URL is incomplete or malformed.</source>
        <translation>图片路径或链接缺损或格式有误。</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/MDEditView.py" line="631"/>
        <source>The protocol &quot;{}&quot; is not supported.</source>
        <translation>不支持该“{}”接口。</translation>
    </message>
</context>
<context>
    <name>MDEditCompleter</name>
    <message>
        <location filename="../manuskript/ui/views/MDEditCompleter.py" line="73"/>
        <source>Insert reference</source>
        <translation>插入引用</translation>
    </message>
</context>
<context>
    <name>MDEditView</name>
    <message>
        <location filename="../manuskript/ui/views/MDEditView.py" line="543"/>
        <source>{} (CTRL+Click to open)</source>
        <translation>{}（按住CTRL并点击以打开）</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1553"/>
        <source>General</source>
        <translation>通用</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1489"/>
        <source>Title</source>
        <translation>标题</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1490"/>
        <source>Subtitle</source>
        <translation>副标</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1491"/>
        <source>Series</source>
        <translation>系列</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1492"/>
        <source>Volume</source>
        <translation>卷册</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1493"/>
        <source>Genre</source>
        <translation>分类</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1494"/>
        <source>License</source>
        <translation>许可</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1495"/>
        <source>Author</source>
        <translation>作者</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1551"/>
        <source>Name</source>
        <translation>名字</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1497"/>
        <source>Email</source>
        <translation>邮箱</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1543"/>
        <source>Summary</source>
        <translation>概要</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1499"/>
        <source>Situation:</source>
        <translation>情境：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1539"/>
        <source>Summary:</source>
        <translation>概要：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1502"/>
        <source>One sentence</source>
        <translation>一句</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1544"/>
        <source>One paragraph</source>
        <translation>一段</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1545"/>
        <source>One page</source>
        <translation>一页</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1546"/>
        <source>Full</source>
        <translation>完整</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1507"/>
        <source>One sentence summary</source>
        <translation>一句概要</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1509"/>
        <source>One paragraph summary</source>
        <translation>一段概要</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1510"/>
        <source>Expand each sentence of your one paragraph summary to a paragraph</source>
        <translation>将一段概要中每句展开为一段</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1511"/>
        <source>One page summary</source>
        <translation>一页概要</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1512"/>
        <source>Full summary</source>
        <translation>完整概要</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1500"/>
        <source>What if...?</source>
        <translation>若…？</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/searchMenu.py" line="24"/>
        <source>Characters</source>
        <translation>角色</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1514"/>
        <source>Names</source>
        <translation>名字</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1548"/>
        <source>Filter</source>
        <translation>过滤</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1538"/>
        <source>Basic info</source>
        <translation>简况</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1534"/>
        <source>Importance</source>
        <translation>分量</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1519"/>
        <source>Motivation</source>
        <translation>动机</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1520"/>
        <source>Goal</source>
        <translation>目标</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1521"/>
        <source>Conflict</source>
        <translation>冲突</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1522"/>
        <source>Epiphany</source>
        <translation>顿悟</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1523"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;One sentence&lt;br/&gt;summary&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;一句&lt;br/&gt;概要&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1524"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;One paragraph&lt;br/&gt;summary&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;一段&lt;br/&gt;概要&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1527"/>
        <source>Notes</source>
        <translation>笔记</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1529"/>
        <source>Detailed info</source>
        <translation>详情</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1562"/>
        <source>Plots</source>
        <translation>情节</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/searchMenu.py" line="27"/>
        <source>Plot</source>
        <translation>情节</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1535"/>
        <source>Character(s)</source>
        <translation>角色</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1552"/>
        <source>Description</source>
        <translation>描述</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1537"/>
        <source>Result</source>
        <translation>结果</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1542"/>
        <source>Resolution steps</source>
        <translation>解决步骤</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/searchMenu.py" line="26"/>
        <source>World</source>
        <translation>世界</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1550"/>
        <source>Populates with empty data</source>
        <translation>填入空数据</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1556"/>
        <source>More</source>
        <translation>更多</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1554"/>
        <source>Source of passion</source>
        <translation>激情来源</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1555"/>
        <source>Source of conflict</source>
        <translation>冲突来源</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/searchMenu.py" line="23"/>
        <source>Outline</source>
        <translation>大纲</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1559"/>
        <source>Editor</source>
        <translation>编辑</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1566"/>
        <source>Debug</source>
        <translation>调试</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/searchMenu.py" line="25"/>
        <source>FlatData</source>
        <translation>平面数据</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1561"/>
        <source>Persos</source>
        <translation>人</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1565"/>
        <source>Labels</source>
        <translation>标签</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1567"/>
        <source>&amp;File</source>
        <translation>文件(&amp;F)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1568"/>
        <source>&amp;Recent</source>
        <translation>最近(&amp;R)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1569"/>
        <source>&amp;Help</source>
        <translation>帮助(&amp;H)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1570"/>
        <source>&amp;Tools</source>
        <translation>工具(&amp;T)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1571"/>
        <source>&amp;Edit</source>
        <translation>编辑(&amp;E)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1574"/>
        <source>&amp;View</source>
        <translation>视图(&amp;V)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1575"/>
        <source>&amp;Mode</source>
        <translation>模式(&amp;M)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1578"/>
        <source>Cheat Sheet</source>
        <translation>速查</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1580"/>
        <source>&amp;Navigation</source>
        <translation>导航</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1581"/>
        <source>&amp;Open</source>
        <translation>打开</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1582"/>
        <source>&amp;Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1583"/>
        <source>Sa&amp;ve as...</source>
        <translation>另存…</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1584"/>
        <source>&amp;Quit</source>
        <translation>退出</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1585"/>
        <source>&amp;Show help texts</source>
        <translation>显示帮助</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1586"/>
        <source>&amp;Spellcheck</source>
        <translation>校订</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1587"/>
        <source>&amp;Labels...</source>
        <translation>标签(&amp;L)…</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1588"/>
        <source>&amp;Status...</source>
        <translation>状态(&amp;S)…</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1589"/>
        <source>Tree</source>
        <translation>树</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1590"/>
        <source>&amp;Simple</source>
        <translation>简单(&amp;S)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1591"/>
        <source>&amp;Fiction</source>
        <translation>虚构(&amp;F)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1592"/>
        <source>Index cards</source>
        <translation>简卡</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1594"/>
        <source>S&amp;ettings</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1595"/>
        <source>&amp;Close project</source>
        <translation>关闭(&amp;C)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1596"/>
        <source>Co&amp;mpile</source>
        <translation>编译</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1597"/>
        <source>&amp;Frequency Analyzer</source>
        <translation>频谱(&amp;F)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1488"/>
        <source>Book information</source>
        <translation>书籍信息</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1598"/>
        <source>&amp;About</source>
        <translation>关于(&amp;A)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1599"/>
        <source>About Manuskript</source>
        <translation>关于Manuskript</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1085"/>
        <source>Manuskript</source>
        <translation>Manuskript</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1217"/>
        <source>Project {} saved.</source>
        <translation>已保存{}项目。</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1221"/>
        <source>WARNING: Project {} not saved.</source>
        <translation>警告：项目{}未保存。</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1240"/>
        <source>Project {} loaded.</source>
        <translation>项目{}已载入。</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1246"/>
        <source>Project {} loaded with some errors.</source>
        <translation>载入项目{}时遇到错误。</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1622"/>
        <source> (~{} pages)</source>
        <translation> （～{}页）</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1625"/>
        <source>Words: {}{}</source>
        <translation>词数：{}{}</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1633"/>
        <source>Book summary</source>
        <translation>书籍概要</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1634"/>
        <source>Project tree</source>
        <translation>项目树</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1635"/>
        <source>Metadata</source>
        <translation>元信息</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1636"/>
        <source>Story line</source>
        <translation>故事线</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1701"/>
        <source>Enter information about your book, and yourself.</source>
        <translation>输入关于你的书和自己的信息。</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1704"/>
        <source>The basic situation, in the form of a &apos;What if...?&apos; question. Ex: &apos;What if the most dangerous
                     evil wizard wasn&apos;t able to kill a baby?&apos; (Harry Potter)</source>
        <translation>基本情境是形如“如果……？”的问题。
例如：“如果一个最危险的巫师没能成功杀死一个婴儿？”（哈利·波特）</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1709"/>
        <source>Take time to think about a one sentence (~50 words) summary of your book. Then expand it to
                     a paragraph, then to a page, then to a full summary.</source>
        <translation>花一些时间想出50词左右的一句话概要来描述你的书。
然后将它扩展成一段，一页，最后写成一个完整的概要。</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1714"/>
        <source>Create your characters.</source>
        <translation>建立角色。</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1717"/>
        <source>Develop plots.</source>
        <translation>构造情节。</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1720"/>
        <source>Build worlds.  Create hierarchy of broad categories down to specific details.</source>
        <translation>构建世界。创造层次丰富、涉及广泛的体系结构，直至具体细节。</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1723"/>
        <source>Create the outline of your masterpiece.</source>
        <translation>建立作品大纲。</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1726"/>
        <source>Write.</source>
        <translation>写作。</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1729"/>
        <source>Debug info. Sometimes useful.</source>
        <translation>调试信息。用有其时。</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1743"/>
        <source>Dictionary</source>
        <translation>词典(&amp;D)</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1891"/>
        <source>Nothing</source>
        <translation>无</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1892"/>
        <source>POV</source>
        <translation>视角</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1893"/>
        <source>Label</source>
        <translation>标签</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1894"/>
        <source>Progress</source>
        <translation>进度</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1895"/>
        <source>Compile</source>
        <translation>编译</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1918"/>
        <source>Icon color</source>
        <translation>图标色</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1919"/>
        <source>Text color</source>
        <translation>文本色</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1920"/>
        <source>Background color</source>
        <translation>背景色</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1911"/>
        <source>Icon</source>
        <translation>图标</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1912"/>
        <source>Text</source>
        <translation>文本</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1913"/>
        <source>Background</source>
        <translation>背景</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1914"/>
        <source>Border</source>
        <translation>边缘</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1915"/>
        <source>Corner</source>
        <translation>角落</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1540"/>
        <source>Add plot step</source>
        <translation>添加情节步骤</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1601"/>
        <source>&amp;Copy</source>
        <translation>复制</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1602"/>
        <source>C&amp;ut</source>
        <translation>剪切</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1603"/>
        <source>&amp;Paste</source>
        <translation>粘贴</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1605"/>
        <source>Sp&amp;lit at cursor</source>
        <translation>分于光标</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1609"/>
        <source>&amp;Move Up</source>
        <translation>上移</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1610"/>
        <source>M&amp;ove Down</source>
        <translation>下移</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1607"/>
        <source>Dupl&amp;icate</source>
        <translation>副本</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1608"/>
        <source>&amp;Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1613"/>
        <source>&amp;Rename</source>
        <translation>改名</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1576"/>
        <source>Organi&amp;ze</source>
        <translation>管理(&amp;Z)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1606"/>
        <source>M&amp;erge</source>
        <translation>合并</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1572"/>
        <source>&amp;Format</source>
        <translation>格式(&amp;F)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1573"/>
        <source>&amp;Header</source>
        <translation>标题(&amp;H)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1614"/>
        <source>&amp;Level 1 (setext)</source>
        <translation>一级标题（===）</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1615"/>
        <source>Level &amp;2</source>
        <translation>二级标题（---）</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1616"/>
        <source>Level &amp;1 (atx)</source>
        <translation>一级标题</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1617"/>
        <source>L&amp;evel 2</source>
        <translation>二级标题</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1618"/>
        <source>Level &amp;3</source>
        <translation>三级标题</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1619"/>
        <source>Level &amp;4</source>
        <translation>四级标题</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1620"/>
        <source>Level &amp;5</source>
        <translation>五级标题</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1621"/>
        <source>Level &amp;6</source>
        <translation>六级标题</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1622"/>
        <source>&amp;Bold</source>
        <translation>粗体</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1623"/>
        <source>&amp;Italic</source>
        <translation>斜体</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1624"/>
        <source>&amp;Strike</source>
        <translation>删线(&amp;S)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1625"/>
        <source>&amp;Verbatim</source>
        <translation>逐字(&amp;V)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1626"/>
        <source>Su&amp;perscript</source>
        <translation>上标</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1627"/>
        <source>Subsc&amp;ript</source>
        <translation>下标</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1628"/>
        <source>Co&amp;mment block</source>
        <translation>块注释</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1629"/>
        <source>Clear &amp;formats</source>
        <translation>清除格式</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1630"/>
        <source>&amp;Comment line(s)</source>
        <translation>行注释</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1631"/>
        <source>&amp;Ordered list</source>
        <translation>有序列表(&amp;O)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1632"/>
        <source>&amp;Unordered list</source>
        <translation>无序列表(&amp;U)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1633"/>
        <source>B&amp;lockquote</source>
        <translation>引用块(&amp;L)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1541"/>
        <source>Remove selected plot step(s)</source>
        <translation>删除所选情节片段</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="923"/>
        <source>The file {} does not exist. Has it been moved or deleted?</source>
        <translation>文件{}不存在。是否被移除？</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1757"/>
        <source>Install {}{} to use spellcheck</source>
        <translation>安装{}{}以使用校订</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1799"/>
        <source>{} has no installed dictionaries</source>
        <translation>{}未装词典</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1820"/>
        <source>{}{} is not installed</source>
        <translation>{}{}未装</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1028"/>
        <source>Save project?</source>
        <translation>保存项目？</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1028"/>
        <source>Save changes to project &quot;{}&quot; before closing?</source>
        <translation>在关闭前保存对项目“{}”的更改？</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1028"/>
        <source>Your changes will be lost if you don&apos;t save them.</source>
        <translation>若不保存，改动会丢失。</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="2018"/>
        <source>PyQt / Qt versions 5.11 and 5.12 are known to cause a crash which might result in a loss of data.</source>
        <translation>已知 PyQt / Qt 5.11 和 5.12 版本会引起崩溃，导致数据丢失。</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="2019"/>
        <source>PyQt {} and Qt {} are in use.</source>
        <translation>正在使用 PyQt {}和 Qt {}。</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="2025"/>
        <source>Proceed with import at your own risk</source>
        <translation>继续导入，风险自负</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1518"/>
        <source>Allow POV</source>
        <translation>可作视角</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1636"/>
        <source>Search</source>
        <translation>搜索</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1637"/>
        <source>&amp;Technical Support</source>
        <translation>技术支持</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1638"/>
        <source>How to obtain technical support for Manuskript.</source>
        <translation>如何获取Manuskript的技术支持。</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1639"/>
        <source>&amp;Locate log file...</source>
        <translation>定位日志…</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1640"/>
        <source>Locate log file</source>
        <translation>定位日志</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1641"/>
        <source>Locate the diagnostic log file used for this session.</source>
        <translation>定位本节软件诊断日志。</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1557"/>
        <source>Sorry!</source>
        <translation>报歉！</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1557"/>
        <source>This session is not being logged.</source>
        <translation>本节不会记录日志。</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1566"/>
        <source>A log file is a Work in Progress!</source>
        <translation>日志正在写入！</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1566"/>
        <source>The log file &quot;{}&quot; will continue to be written to until Manuskript is closed.</source>
        <translation>Manuskript关闭前将继续写入日志“{}”。</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1566"/>
        <source>It will now be displayed in your file manager, but is of limited use until you close Manuskript.</source>
        <translation>它将显示在文件管理器中，但关闭Manuskript前，您对该文件操作受限。</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1582"/>
        <source>Error!</source>
        <translation>出错！</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1582"/>
        <source>An error was encountered while trying to show the log file below in your file manager.</source>
        <translation>尝试在文件管理器中显示以下日志时出错。</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/search.py" line="51"/>
        <source>F3</source>
        <translation>F3</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/search.py" line="52"/>
        <source>Shift+F3</source>
        <translation>Shift+F3</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/search.py" line="56"/>
        <source>Situation</source>
        <translation>情境</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/search.py" line="57"/>
        <source>Status</source>
        <translation>状态</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1600"/>
        <source>&amp;Import…</source>
        <translation>导入…</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1604"/>
        <source>&amp;Split…</source>
        <translation>分割…</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1634"/>
        <source>&amp;Targets</source>
        <translation>目标</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1635"/>
        <source>Draft and session word count targets</source>
        <translation>草稿与本节词数目标</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="385"/>
        <source>Value</source>
        <translation>值</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="393"/>
        <source>Bulk Info Manager</source>
        <translation>信息批量管理</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="438"/>
        <source>No Entries!</source>
        <translation>没有条目！</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="438"/>
        <source>Please add entries to apply to the selected characters.</source>
        <translation>请加入条目以作用于所选角色。</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="449"/>
        <source>Bulk Info Applied</source>
        <translation>信息批量应用</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="449"/>
        <source>The bulk info has been applied to the selected characters.</source>
        <translation>批量信息已应用至所选角色。</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="521"/>
        <source>Un-applied data!</source>
        <translation>未应用数据！</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="521"/>
        <source>There are un-applied entries in this tab. Discard them?</source>
        <translation>本选项卡中含有未应用条目。是否舍弃？</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1577"/>
        <source>&amp;Navigate</source>
        <translation>导航(&amp;N)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1611"/>
        <source>Go &amp;back</source>
        <translation>后退</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.py" line="1612"/>
        <source>Go &amp;forward</source>
        <translation>前进</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1251"/>
        <source>Loading project {} failed.</source>
        <translation>{}项目加载失败。</translation>
    </message>
</context>
<context>
    <name>Search</name>
    <message>
        <location filename="../manuskript/ui/search.py" line="46"/>
        <source>No results found</source>
        <translation>查找无果</translation>
    </message>
</context>
<context>
    <name>Settings</name>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1837"/>
        <source>Settings</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1841"/>
        <source>General</source>
        <translation>通用</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1873"/>
        <source>Revisions</source>
        <translation>修订</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1845"/>
        <source>Views</source>
        <translation>视图</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2035"/>
        <source>Labels</source>
        <translation>标签</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2036"/>
        <source>Status</source>
        <translation>状态</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2037"/>
        <source>Fullscreen</source>
        <translation>全屏</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1855"/>
        <source>General settings</source>
        <translation>通用设置</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1856"/>
        <source>Application settings</source>
        <translation>应用设置</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1863"/>
        <source>Loading</source>
        <translation>载入</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1864"/>
        <source>Automatically load last project on startup</source>
        <translation>启动时打开最后关闭的项目</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1865"/>
        <source>Saving</source>
        <translation>保存</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1866"/>
        <source>Automatically save every</source>
        <translation>自动保存每</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1867"/>
        <source>minutes.</source>
        <translation>分钟。</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1868"/>
        <source>If no changes during</source>
        <translation>若不变动已</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1869"/>
        <source>seconds.</source>
        <translation>秒钟。</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1870"/>
        <source>Save on project close</source>
        <translation>关闭项目时保存</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1871"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If you check this option, your project will be saved as one single file. Easier to copy or backup, but does not allow collaborative editing, or versioning.&lt;br/&gt;If this is unchecked, your project will be saved as a folder containing many small files.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;若选此项，项目会保存为单文件。更易于复制与备份，但无法协作编辑或版本控制。&lt;br/&gt;否则，项目会保存为一个包含多文件的文件夹。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1872"/>
        <source>Save to one single file</source>
        <translation>保存到单文件</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1874"/>
        <source>Revisions are a way to keep track of modifications. For each text item, it stores any changes you make to the main text, allowing you to see and restoring previous versions.</source>
        <translation>修订用于跟踪内容编辑。存储各文本项正文的任何更改，以便查看和回溯。</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1875"/>
        <source>Keep revisions</source>
        <translation>保留修订</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1876"/>
        <source>S&amp;mart remove</source>
        <translation>智能删除</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1877"/>
        <source>Keep:</source>
        <translation>保留：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1878"/>
        <source>Smart remove allows you to keep only a certain number of revisions. It is strongly recommended to use it, lest your files would be bloated with thousands of insignificant changes.</source>
        <translation>智能删除可限制修订数，宜开启以免保留过多微修订。</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1879"/>
        <source>revisions per day for the last month</source>
        <translation>份修订/天，近一月</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1880"/>
        <source>revisions per minute for the last 10 minutes</source>
        <translation>份修订/分，近十分</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1881"/>
        <source>revisions per hour for the last day</source>
        <translation>份修订/时，近一日</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1882"/>
        <source>revisions per 10 minutes for the last hour</source>
        <translation>份修订/十分，近一时</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1883"/>
        <source>revisions per week till the end of time</source>
        <translation>份修订/周，一直</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1885"/>
        <source>Views settings</source>
        <translation>视图设置</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1922"/>
        <source>Tree</source>
        <translation>树</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1990"/>
        <source>Colors</source>
        <translation>颜色</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1959"/>
        <source>Icon color:</source>
        <translation>图标色：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1984"/>
        <source>Nothing</source>
        <translation>无</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1985"/>
        <source>POV</source>
        <translation>视角</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1986"/>
        <source>Label</source>
        <translation>标签</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1987"/>
        <source>Progress</source>
        <translation>进度</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1988"/>
        <source>Compile</source>
        <translation>编译</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2097"/>
        <source>Text color:</source>
        <translation>文本色：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2098"/>
        <source>Background color:</source>
        <translation>背景色：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1909"/>
        <source>Folders</source>
        <translation>文件夹</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1910"/>
        <source>Show ite&amp;m count</source>
        <translation>显示项数</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1920"/>
        <source>Show summary</source>
        <translation>显示概要</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1915"/>
        <source>&amp;Nothing</source>
        <translation>无</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1916"/>
        <source>Text</source>
        <translation>文本</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1951"/>
        <source>Outline</source>
        <translation>大纲</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1942"/>
        <source>Visible columns</source>
        <translation>可见列</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1943"/>
        <source>Goal</source>
        <translation>目标</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1944"/>
        <source>Word count</source>
        <translation>词数</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1945"/>
        <source>Percentage</source>
        <translation>百分</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1950"/>
        <source>Title</source>
        <translation>标题</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1989"/>
        <source>Index cards</source>
        <translation>简卡</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1958"/>
        <source>Item colors</source>
        <translation>项目色</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2099"/>
        <source>Border color:</source>
        <translation>边缘色：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1983"/>
        <source>Corner color:</source>
        <translation>角落色：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1952"/>
        <source>Background</source>
        <translation>背景</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2073"/>
        <source>Color:</source>
        <translation>字色：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2049"/>
        <source>Image:</source>
        <translation>图像：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2034"/>
        <source>Text editor</source>
        <translation>文本编辑</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1995"/>
        <source>Font</source>
        <translation>字体</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1996"/>
        <source>Family:</source>
        <translation>字体：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2075"/>
        <source>Size:</source>
        <translation>尺寸：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2076"/>
        <source>Misspelled:</source>
        <translation>拼错：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1991"/>
        <source>Background:</source>
        <translation>背景：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2006"/>
        <source>Paragraphs</source>
        <translation>段</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2077"/>
        <source>Line spacing:</source>
        <translation>行距：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2078"/>
        <source>Single</source>
        <translation>单行</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2079"/>
        <source>1.5 lines</source>
        <translation>1.5行</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2080"/>
        <source>Double</source>
        <translation>双行</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2081"/>
        <source>Proportional</source>
        <translation>比例</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2082"/>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2083"/>
        <source>Tab width:</source>
        <translation>制表宽：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2087"/>
        <source> px</source>
        <translation> 像素</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2088"/>
        <source>Indent 1st line</source>
        <translation>首行缩进</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2085"/>
        <source>Spacing:</source>
        <translation>间距：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2038"/>
        <source>New</source>
        <translation>新建</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2039"/>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2040"/>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2041"/>
        <source>Theme name:</source>
        <translation>主题：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2042"/>
        <source>Apply</source>
        <translation>应用</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2043"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2044"/>
        <source>Window Background</source>
        <translation>窗口背景</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2045"/>
        <source>Text Background</source>
        <translation>文本背景</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2046"/>
        <source>Text Options</source>
        <translation>文本选项</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2047"/>
        <source>Paragraph Options</source>
        <translation>段选项</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2050"/>
        <source>Type:</source>
        <translation>类型：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2051"/>
        <source>No Image</source>
        <translation>无图</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2052"/>
        <source>Tiled</source>
        <translation>平铺</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2053"/>
        <source>Centered</source>
        <translation>中心</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2064"/>
        <source>Stretched</source>
        <translation>拉伸</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2055"/>
        <source>Scaled</source>
        <translation>比例</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2056"/>
        <source>Zoomed</source>
        <translation>缩放</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2058"/>
        <source>Opacity:</source>
        <translation>透明：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2060"/>
        <source>Position:</source>
        <translation>位置：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2089"/>
        <source>Left</source>
        <translation>左</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2090"/>
        <source>Center</source>
        <translation>中</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2091"/>
        <source>Right</source>
        <translation>右</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2065"/>
        <source>Width:</source>
        <translation>宽：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2068"/>
        <source>Corner radius:</source>
        <translation>角径：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2069"/>
        <source>Margins:</source>
        <translation>边距：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2071"/>
        <source>Padding:</source>
        <translation>内距：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2074"/>
        <source>Font:</source>
        <translation>字体：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2094"/>
        <source>Style</source>
        <translation>样式</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2024"/>
        <source>Cursor</source>
        <translation>光标</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2025"/>
        <source>Use block insertion of</source>
        <translation>块状插标</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2007"/>
        <source>Alignment:</source>
        <translation>对齐：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2092"/>
        <source>Justify</source>
        <translation>校正</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2093"/>
        <source>Alignment</source>
        <translation>对齐</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1905"/>
        <source>Icon Size</source>
        <translation>图标尺寸</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1906"/>
        <source>TextLabel</source>
        <translation>文本标签</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2027"/>
        <source>Disable blinking</source>
        <translation>关闭闪烁</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1999"/>
        <source>Text area</source>
        <translation>文本框</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2000"/>
        <source>Max width</source>
        <translation>最宽</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2002"/>
        <source>Left/Right margins:</source>
        <translation>横边距：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2004"/>
        <source>Top/Bottom margins:</source>
        <translation>纵边距：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1913"/>
        <source>S&amp;how progress</source>
        <translation>显示进度</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1914"/>
        <source>Show summar&amp;y</source>
        <translation>显示概要</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1919"/>
        <source>Show p&amp;rogress</source>
        <translation>显示进度</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1956"/>
        <source>Old st&amp;yle</source>
        <translation>旧样式(&amp;Y)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1992"/>
        <source>Transparent</source>
        <translation>透明</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1994"/>
        <source>Restore defaults</source>
        <translation>恢复默认</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1858"/>
        <source>Style:</source>
        <translation>样式：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1859"/>
        <source>Language:</source>
        <translation>语言：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1860"/>
        <source>Font size:</source>
        <translation>字号：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1857"/>
        <source>Restarting Manuskript ensures all settings take effect.</source>
        <translation>重启Manuskript以生效设置。</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1911"/>
        <source>Show &amp;word count</source>
        <translation>显示词数</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1917"/>
        <source>&amp;Show word count</source>
        <translation>显示词数</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1957"/>
        <source>&amp;New style</source>
        <translation>新样式(&amp;N)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2028"/>
        <source>Typewriter mode</source>
        <translation>打字机式</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2029"/>
        <source>Focus mode</source>
        <translation>专注模式</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2030"/>
        <source>None</source>
        <translation>无</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2031"/>
        <source>Sentence</source>
        <translation>句</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2032"/>
        <source>Line</source>
        <translation>行</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2033"/>
        <source>Paragraph</source>
        <translation>段</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1884"/>
        <source>&lt;p&gt;&lt;b&gt;The Revisions feature has been at the source of many reported issues. In this version of Manuskript it has been turned off by default for new projects in order to provide the best experience.&lt;/b&gt;&lt;/p&gt;&lt;p&gt;Why aren&apos;t these issues fixed already? &lt;a href=&quot;https://www.theologeek.ch/manuskript/contribute/&quot;&gt;We need your help to make Manuskript better!&lt;/a&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;修订功能被报有障。此版Manuskript新建项目时，默认关闭以使体验最佳。&lt;/b&gt;&lt;/p&gt;&lt;p&gt;为何故障尚未修复？&lt;a href=&quot;https://www.theologeek.ch/manuskript/contribute/&quot;&gt;我们需要你帮助改善Manuskript！&lt;/a&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1861"/>
        <source>Show progress in chars next
 to words</source>
        <translation>在词数进度旁
显示字数进度</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1907"/>
        <source>Char/Word Counter</source>
        <translation>字词计数</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1908"/>
        <source>Count spaces as chars</source>
        <translation>空格归字符</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1912"/>
        <source>Show char c&amp;ount</source>
        <translation>显示字数</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="1918"/>
        <source>Sho&amp;w char count</source>
        <translation>显示字数</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2095"/>
        <source>Tooltips</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.py" line="2096"/>
        <source>Use system defaults</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SpellAction</name>
    <message>
        <location filename="../manuskript/ui/views/textEditView.py" line="622"/>
        <source>Spelling Suggestions</source>
        <translation>拼写建议</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/textEditView.py" line="641"/>
        <source>&amp;Add to dictionary</source>
        <translation>加入词典(&amp;A)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/textEditView.py" line="694"/>
        <source>&amp;Remove from custom dictionary</source>
        <translation>从个人词典中删除(&amp;R)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/textEditView.py" line="549"/>
        <source>&amp;New Character</source>
        <translation>新角色(&amp;N)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/textEditView.py" line="556"/>
        <source>&amp;New Plot Item</source>
        <translation>新情节项(&amp;N)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/textEditView.py" line="563"/>
        <source>&amp;New World Item</source>
        <translation>新世界项(&amp;N)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/textEditView.py" line="665"/>
        <source>&amp;Correction Suggestions</source>
        <translation>更正建议(&amp;C)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/textEditView.py" line="674"/>
        <source>&amp;Correction Suggestion</source>
        <translation>更正建议(&amp;C)</translation>
    </message>
</context>
<context>
    <name>about</name>
    <message>
        <location filename="../manuskript/ui/about_ui.py" line="54"/>
        <source>About Manuskript</source>
        <translation>关于Manuskript</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/about_ui.py" line="55"/>
        <source>Manuskript</source>
        <translation>Manuskript</translation>
    </message>
</context>
<context>
    <name>aboutDialog</name>
    <message>
        <location filename="../manuskript/ui/about.py" line="31"/>
        <source>Version</source>
        <translation>版本</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/about.py" line="44"/>
        <source>Software Versions in Use:</source>
        <translation>当前软件版本：</translation>
    </message>
</context>
<context>
    <name>abstractModel</name>
    <message>
        <location filename="../manuskript/models/abstractModel.py" line="215"/>
        <source>Title</source>
        <translation>标题</translation>
    </message>
    <message>
        <location filename="../manuskript/models/abstractModel.py" line="217"/>
        <source>POV</source>
        <translation>视角</translation>
    </message>
    <message>
        <location filename="../manuskript/models/abstractModel.py" line="219"/>
        <source>Label</source>
        <translation>标签</translation>
    </message>
    <message>
        <location filename="../manuskript/models/abstractModel.py" line="221"/>
        <source>Status</source>
        <translation>状态</translation>
    </message>
    <message>
        <location filename="../manuskript/models/abstractModel.py" line="223"/>
        <source>Compile</source>
        <translation>编纂</translation>
    </message>
    <message>
        <location filename="../manuskript/models/abstractModel.py" line="225"/>
        <source>Word count</source>
        <translation>词数</translation>
    </message>
    <message>
        <location filename="../manuskript/models/abstractModel.py" line="227"/>
        <source>Goal</source>
        <translation>目标</translation>
    </message>
</context>
<context>
    <name>basicItemView</name>
    <message>
        <location filename="../manuskript/ui/views/basicItemView_ui.py" line="65"/>
        <source>Form</source>
        <translation>表格</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/basicItemView_ui.py" line="66"/>
        <source>POV:</source>
        <translation>视角：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/basicItemView_ui.py" line="67"/>
        <source>Goal:</source>
        <translation>目标：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/basicItemView_ui.py" line="68"/>
        <source>Word count</source>
        <translation>词数</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/basicItemView_ui.py" line="69"/>
        <source>One line summary</source>
        <translation>一行概要</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/basicItemView_ui.py" line="70"/>
        <source>Few sentences summary:</source>
        <translation>几句概要：</translation>
    </message>
</context>
<context>
    <name>characterInfoDialog</name>
    <message>
        <location filename="../manuskript/ui/characterInfoDialog.py" line="94"/>
        <source>Add Character Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../manuskript/ui/characterInfoDialog.py" line="95"/>
        <source>Value:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../manuskript/ui/characterInfoDialog.py" line="96"/>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>characterModel</name>
    <message>
        <location filename="../manuskript/models/characterModel.py" line="206"/>
        <source>Name</source>
        <translation>名字</translation>
    </message>
    <message>
        <location filename="../manuskript/models/characterModel.py" line="215"/>
        <source>Value</source>
        <translation>值</translation>
    </message>
    <message>
        <location filename="../manuskript/models/characterModel.py" line="179"/>
        <source>New character</source>
        <translation>新角色</translation>
    </message>
    <message>
        <location filename="../manuskript/models/characterModel.py" line="215"/>
        <source>Description</source>
        <translation>描述</translation>
    </message>
</context>
<context>
    <name>characterTreeView</name>
    <message>
        <location filename="../manuskript/ui/views/characterTreeView.py" line="33"/>
        <source>Main</source>
        <translation>主要</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/characterTreeView.py" line="33"/>
        <source>Secondary</source>
        <translation>次要</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/characterTreeView.py" line="33"/>
        <source>Minor</source>
        <translation>轻微</translation>
    </message>
</context>
<context>
    <name>cheatSheet</name>
    <message>
        <location filename="../manuskript/ui/cheatSheet_ui.py" line="89"/>
        <source>Form</source>
        <translation>表格</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/cheatSheet_ui.py" line="90"/>
        <source>Filter (type the name of anything in your project)</source>
        <translation>过滤（输入项目中任意名字）</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/cheatSheet.py" line="113"/>
        <source>Minor</source>
        <translation>轻微</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/cheatSheet.py" line="113"/>
        <source>Secondary</source>
        <translation>次要</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/cheatSheet.py" line="113"/>
        <source>Main</source>
        <translation>主要</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/cheatSheet.py" line="91"/>
        <source>Characters</source>
        <translation>角色</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/cheatSheet.py" line="104"/>
        <source>Texts</source>
        <translation>文本</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/cheatSheet.py" line="116"/>
        <source>Plots</source>
        <translation>情节</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/cheatSheet.py" line="120"/>
        <source>World</source>
        <translation>世界</translation>
    </message>
</context>
<context>
    <name>cmbOutlineCharacterChoser</name>
    <message>
        <location filename="../manuskript/ui/views/cmbOutlineCharacterChoser.py" line="34"/>
        <source>None</source>
        <translation>无</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/cmbOutlineCharacterChoser.py" line="36"/>
        <source>Main</source>
        <translation>主要</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/cmbOutlineCharacterChoser.py" line="36"/>
        <source>Secondary</source>
        <translation>次要</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/cmbOutlineCharacterChoser.py" line="36"/>
        <source>Minor</source>
        <translation>轻微</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/cmbOutlineCharacterChoser.py" line="136"/>
        <source>Various</source>
        <translation>可变</translation>
    </message>
</context>
<context>
    <name>cmbOutlineLabelChoser</name>
    <message>
        <location filename="../manuskript/ui/views/cmbOutlineLabelChoser.py" line="113"/>
        <source>Various</source>
        <translation>可变</translation>
    </message>
</context>
<context>
    <name>cmbOutlineStatusChoser</name>
    <message>
        <location filename="../manuskript/ui/views/cmbOutlineStatusChoser.py" line="112"/>
        <source>Various</source>
        <translation>可变</translation>
    </message>
</context>
<context>
    <name>collapsibleDockWidgets</name>
    <message>
        <location filename="../manuskript/ui/collapsibleDockWidgets.py" line="26"/>
        <source>Dock Widgets Toolbar</source>
        <translation>停靠组件栏</translation>
    </message>
</context>
<context>
    <name>completer</name>
    <message>
        <location filename="../manuskript/ui/editors/completer_ui.py" line="34"/>
        <source>Form</source>
        <translation>表格</translation>
    </message>
</context>
<context>
    <name>corkDelegate</name>
    <message>
        <location filename="../manuskript/ui/views/corkDelegate.py" line="70"/>
        <source>One line summary</source>
        <translation>一行概要</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/corkDelegate.py" line="100"/>
        <source>Full summary</source>
        <translation>完整概要</translation>
    </message>
</context>
<context>
    <name>dlg</name>
    <message>
        <location filename="../manuskript/load_save/version_1.py" line="436"/>
        <source>Files not saved</source>
        <translation>文件未保存</translation>
    </message>
    <message>
        <location filename="../manuskript/load_save/version_1.py" line="437"/>
        <source>The following files were not saved and appear to be open in another program</source>
        <translation>以下文件未保存且似乎已在另一个程序中打开</translation>
    </message>
    <message>
        <location filename="../manuskript/load_save/version_1.py" line="933"/>
        <source>Files not loaded</source>
        <translation>文件未加载</translation>
    </message>
    <message>
        <location filename="../manuskript/load_save/version_1.py" line="934"/>
        <source>The following files were not loaded and appear to be open in another program</source>
        <translation>以下文件未加载且似乎已在另一个程序中打开</translation>
    </message>
</context>
<context>
    <name>editorWidget_ui</name>
    <message>
        <location filename="../manuskript/ui/editors/editorWidget_ui.py" line="75"/>
        <source>Form</source>
        <translation>表格</translation>
    </message>
</context>
<context>
    <name>exporter</name>
    <message>
        <location filename="../manuskript/ui/exporters/exporter_ui.py" line="70"/>
        <source>Export</source>
        <translation>导出</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exporter_ui.py" line="67"/>
        <source>Export to:</source>
        <translation>导出到：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exporter_ui.py" line="68"/>
        <source>Manage exporters</source>
        <translation>管理导出</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exporter_ui.py" line="72"/>
        <source>Preview</source>
        <translation>预览</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exporter_ui.py" line="71"/>
        <source>Settings</source>
        <translation>设置</translation>
    </message>
</context>
<context>
    <name>exporterDialog</name>
    <message>
        <location filename="../manuskript/ui/exporters/exporter.py" line="64"/>
        <source>{} (not implemented yet)</source>
        <translation>{}（未竟）</translation>
    </message>
</context>
<context>
    <name>exporterSettings</name>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="512"/>
        <source>Form</source>
        <translation>表格</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="527"/>
        <source>Content</source>
        <translation>内容</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="513"/>
        <source>Decide here what will be included in the final export.</source>
        <translation>决定哪些最终导出。</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="515"/>
        <source>Type</source>
        <translation>类型</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="517"/>
        <source>Title</source>
        <translation>标题</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="519"/>
        <source>Text</source>
        <translation>文本</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="520"/>
        <source>I need more granularity</source>
        <translation>我需要更细的粒度</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="521"/>
        <source>Fi&amp;lters</source>
        <translation>过滤(&amp;L)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="522"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filters what items will be included in the final export.&lt;br/&gt;&lt;span style=&quot; color:#773333;&quot;&gt;(Not fully implemented yet.)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;项目过滤器会含在最终导出中&lt;br/&gt;&lt;span style=&quot; color:#773333;&quot;&gt;（尚未完全应用。）&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="523"/>
        <source>Ignore compile status (include all items)</source>
        <translation>忽略编译状态（含所有项）</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="524"/>
        <source>Subitems of:</source>
        <translation>子项：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="525"/>
        <source>Labels</source>
        <translation>标签</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="526"/>
        <source>Status</source>
        <translation>状态</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="540"/>
        <source>Separations</source>
        <translation>分隔</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="528"/>
        <source>Between folders:</source>
        <translation>在文件夹间：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="538"/>
        <source>Empty line</source>
        <translation>空行</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="539"/>
        <source>Custom</source>
        <translation>自设</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="531"/>
        <source>Between texts:</source>
        <translation>在文本间：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="534"/>
        <source>Between folder and text:</source>
        <translation>在文件夹和文本间：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="537"/>
        <source>Between text and folder:</source>
        <translation>在文本和文件夹间：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="557"/>
        <source>Transformations</source>
        <translation>转换</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="541"/>
        <source>Typographic replacements:</source>
        <translation>排版替换：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="544"/>
        <source>Replace double quotes (&quot;) with:</source>
        <translation>替换直双引号（&quot;）为：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="545"/>
        <source>Replace single quotes (&apos;) with:</source>
        <translation>替换直单引号（'）为：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="546"/>
        <source>Remove multiple spaces</source>
        <translation>删除重复空格</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="547"/>
        <source>Custom replacements:</source>
        <translation>自设替换：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="549"/>
        <source>Enabled</source>
        <translation>开启</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="551"/>
        <source>Replace</source>
        <translation>替换</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="553"/>
        <source>With</source>
        <translation>用</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="555"/>
        <source>RegExp</source>
        <translation>正则表达式</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="556"/>
        <source>If checked, uses regular expression for replacement. If unchecked, replaced as plain text.</source>
        <translation>选中则以正则表达式替换。否则以纯文本。</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="561"/>
        <source>Preview</source>
        <translation>预览</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="558"/>
        <source>Font</source>
        <translation>字体</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="559"/>
        <source>Font:</source>
        <translation>字体：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="560"/>
        <source>Font size:</source>
        <translation>字号：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings.py" line="320"/>
        <source>Folder</source>
        <translation>文件夹</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings.py" line="343"/>
        <source>{}Level {} folder</source>
        <translation>{}级别{}文件夹</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings.py" line="346"/>
        <source>{}Level {} text</source>
        <translation>{}级别{}文本</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="542"/>
        <source>Replace ... with …</source>
        <translation>替换...为…</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.py" line="543"/>
        <source>Replace --- with —</source>
        <translation>替换---为—</translation>
    </message>
</context>
<context>
    <name>exportersManager</name>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager.py" line="81"/>
        <source>Installed</source>
        <translation>已装</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager.py" line="87"/>
        <source>Custom</source>
        <translation>自设</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager.py" line="93"/>
        <source>Not found</source>
        <translation>未找到</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager.py" line="96"/>
        <source>{} not found. Install it, or set path manually.</source>
        <translation>未找到{}，安装或手动指定路径。</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager.py" line="124"/>
        <source>&lt;b&gt;Status:&lt;/b&gt; uninstalled.</source>
        <translation>&lt;b&gt;状态：&lt;/b&gt;未装。</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager.py" line="126"/>
        <source>&lt;b&gt;Requires:&lt;/b&gt; </source>
        <translation>&lt;b&gt;需要：&lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager.py" line="133"/>
        <source>Set {} executable path.</source>
        <translation>设置{}可执行文件的路径。</translation>
    </message>
</context>
<context>
    <name>frequencyAnalyzer</name>
    <message>
        <location filename="../manuskript/ui/tools/frequencyAnalyzer.py" line="70"/>
        <source>Phrases</source>
        <translation>词组</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequencyAnalyzer.py" line="108"/>
        <source>Frequency</source>
        <translation>频率</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequencyAnalyzer.py" line="108"/>
        <source>Word</source>
        <translation>词</translation>
    </message>
</context>
<context>
    <name>fullScreenEditor</name>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="133"/>
        <source>Theme:</source>
        <translation>主题：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="364"/>
        <source>{} words / {}</source>
        <translation>{}词/{}</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="368"/>
        <source>{} words</source>
        <translation>{}词</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="153"/>
        <source>Spellcheck</source>
        <translation>校订</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="154"/>
        <source>Navigation</source>
        <translation>导航</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="155"/>
        <source>New Text</source>
        <translation>新文本</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="156"/>
        <source>Title</source>
        <translation>标题</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="157"/>
        <source>Title: Show Full Path</source>
        <translation>标题：显示完整路径</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="159"/>
        <source>Theme selector</source>
        <translation>主题选择</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="160"/>
        <source>Word count</source>
        <translation>词数</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="161"/>
        <source>Progress</source>
        <translation>进度</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="162"/>
        <source>Progress: Auto Show/Hide</source>
        <translation>进度：自动显示/隐藏</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="163"/>
        <source>Clock</source>
        <translation>时钟</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="164"/>
        <source>Clock: Show Seconds</source>
        <translation>时钟：显示秒数</translation>
    </message>
</context>
<context>
    <name>generalSettings</name>
    <message>
        <location filename="../manuskript/ui/importers/generalSettings_ui.py" line="67"/>
        <source>General</source>
        <translation>通用</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/generalSettings_ui.py" line="62"/>
        <source>Split scenes at:</source>
        <translation>拆分场景：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/generalSettings_ui.py" line="63"/>
        <source>\n---\n</source>
        <translation>\n---\n</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/generalSettings_ui.py" line="64"/>
        <source>Trim long titles (&gt; 32 chars)</source>
        <translation>缩短标题（&gt;32字）</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/generalSettings_ui.py" line="65"/>
        <source>Import under:</source>
        <translation>导入到：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/generalSettings_ui.py" line="66"/>
        <source>Import in a top-level folder</source>
        <translation>导入到顶层文件夹</translation>
    </message>
</context>
<context>
    <name>helpLabel</name>
    <message>
        <location filename="../manuskript/ui/helpLabel.py" line="12"/>
        <source>If you don&apos;t wanna see me, you can hide me in Help menu.</source>
        <translation>若不想见，可在帮助菜单中隐藏。</translation>
    </message>
</context>
<context>
    <name>importer</name>
    <message>
        <location filename="../manuskript/ui/importers/importer_ui.py" line="103"/>
        <source>Import</source>
        <translation>导入</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/importer_ui.py" line="99"/>
        <source>Format:</source>
        <translation>格式：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/importer_ui.py" line="100"/>
        <source>Choose file</source>
        <translation>选择文件</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/importer_ui.py" line="101"/>
        <source>Clear file</source>
        <translation>清除文件</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/importer_ui.py" line="105"/>
        <source>Preview</source>
        <translation>预览</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/importer_ui.py" line="104"/>
        <source>Settings</source>
        <translation>设置</translation>
    </message>
</context>
<context>
    <name>lineEditView</name>
    <message>
        <location filename="../manuskript/ui/views/lineEditView.py" line="114"/>
        <source>Various</source>
        <translation>可变</translation>
    </message>
</context>
<context>
    <name>locker</name>
    <message>
        <location filename="../manuskript/ui/editors/locker_ui.py" line="52"/>
        <source>Form</source>
        <translation>表格</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker_ui.py" line="53"/>
        <source>Lock screen:</source>
        <translation>锁定屏幕：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker_ui.py" line="54"/>
        <source>Word target</source>
        <translation>词数目标</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker_ui.py" line="55"/>
        <source>Time target</source>
        <translation>时间目标</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker_ui.py" line="56"/>
        <source> words</source>
        <translation> 词</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker_ui.py" line="57"/>
        <source> minutes</source>
        <translation> 分钟</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker_ui.py" line="58"/>
        <source>Lock !</source>
        <translation>锁定！</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker.py" line="94"/>
        <source>~{} h.</source>
        <translation>～{}小时。</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker.py" line="96"/>
        <source>~{} mn.</source>
        <translation>～{}分钟。</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker.py" line="100"/>
        <source>{}:{}</source>
        <translation>{}:{}</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker.py" line="102"/>
        <source>{} s.</source>
        <translation>{}秒。</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker.py" line="104"/>
        <source>{} remaining</source>
        <translation>余{}</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker.py" line="109"/>
        <source>{} words remaining</source>
        <translation>余词{}</translation>
    </message>
</context>
<context>
    <name>mainEditor</name>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor_ui.py" line="93"/>
        <source>Form</source>
        <translation>表格</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor_ui.py" line="96"/>
        <source>Text</source>
        <translation>文本</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor_ui.py" line="97"/>
        <source>Index cards</source>
        <translation>简卡</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor_ui.py" line="98"/>
        <source>Outline</source>
        <translation>大纲</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor_ui.ui" line="198"/>
        <source>F11</source>
        <translation>F11</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor_ui.py" line="94"/>
        <source>Go to parent item</source>
        <translation>到父项</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor_ui.ui" line="57"/>
        <source>Alt+Up</source>
        <translation>Alt+Up</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor.py" line="258"/>
        <source>Root</source>
        <translation>根</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor.py" line="397"/>
        <source>{} words </source>
        <translation>{}词 </translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor.py" line="378"/>
        <source>({} chars) {}  words / {} </source>
        <translation>（{}字）{}词/{} </translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor.py" line="384"/>
        <source>{}  words / {} </source>
        <translation>{}词/{} </translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor.py" line="399"/>
        <source>{} chars</source>
        <translation>{}字</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor.py" line="393"/>
        <source>{} chars </source>
        <translation>{}字 </translation>
    </message>
</context>
<context>
    <name>markdownSettings</name>
    <message>
        <location filename="../manuskript/exporter/manuskript/markdown.py" line="58"/>
        <source>Markdown</source>
        <translation>Markdown</translation>
    </message>
</context>
<context>
    <name>metadataView</name>
    <message>
        <location filename="../manuskript/ui/views/metadataView_ui.py" line="94"/>
        <source>Form</source>
        <translation>表格</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/metadataView_ui.py" line="95"/>
        <source>Properties</source>
        <translation>属性</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/metadataView_ui.py" line="96"/>
        <source>Summary</source>
        <translation>概要</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/metadataView_ui.py" line="97"/>
        <source>One line summary</source>
        <translation>一行概要</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/metadataView_ui.py" line="98"/>
        <source>Full summary</source>
        <translation>完整概要</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/metadataView_ui.py" line="100"/>
        <source>Notes / References</source>
        <translation>笔记/引用</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/metadataView_ui.py" line="101"/>
        <source>Revisions</source>
        <translation>修订</translation>
    </message>
</context>
<context>
    <name>myPanel</name>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="599"/>
        <source>Auto-hide</source>
        <translation>自动隐藏</translation>
    </message>
</context>
<context>
    <name>outlineCharacterDelegate</name>
    <message>
        <location filename="../manuskript/ui/views/outlineDelegates.py" line="141"/>
        <source>None</source>
        <translation>无</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineDelegates.py" line="143"/>
        <source>Main</source>
        <translation>主要</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineDelegates.py" line="143"/>
        <source>Secondary</source>
        <translation>次要</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineDelegates.py" line="143"/>
        <source>Minor</source>
        <translation>轻微</translation>
    </message>
</context>
<context>
    <name>pandocSettings</name>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="254"/>
        <source>General</source>
        <translation>通用</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="256"/>
        <source>Table of Content</source>
        <translation>目录</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="255"/>
        <source>Custom settings for {}</source>
        <translation>{}自设</translation>
    </message>
</context>
<context>
    <name>persosProxyModel</name>
    <message>
        <location filename="../manuskript/models/persosProxyModel.py" line="16"/>
        <source>Main</source>
        <translation>主要</translation>
    </message>
    <message>
        <location filename="../manuskript/models/persosProxyModel.py" line="17"/>
        <source>Secondary</source>
        <translation>次要</translation>
    </message>
    <message>
        <location filename="../manuskript/models/persosProxyModel.py" line="18"/>
        <source>Minors</source>
        <translation>轻微</translation>
    </message>
</context>
<context>
    <name>plotDelegate</name>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>General</source>
        <translation>通用</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Promise</source>
        <translation>期待</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Problem</source>
        <translation>问题</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Progress</source>
        <translation>进展</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Resolution</source>
        <translation>解决</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Try / Fail</source>
        <translation>尝试/失败</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>No and</source>
        <translation>不，且</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Yes but</source>
        <translation>是，但</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Freytag&apos;s pyramid</source>
        <translation>剧情锥塔</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Exposition</source>
        <translation>揭露</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Rising action</source>
        <translation>上升情节</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Climax</source>
        <translation>高潮</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Falling action</source>
        <translation>下降情节</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Three acts</source>
        <translation>三幕</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>1. Setup</source>
        <translation>1.建立</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>1. Inciting event</source>
        <translation>1.刺激事件</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>1. Turning point</source>
        <translation>1.转折点</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>2. Choice</source>
        <translation>2.选择</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>2. Reversal</source>
        <translation>2.反转</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>2. Disaster</source>
        <translation>2.灾难</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>3. Stand up</source>
        <translation>3.振作</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>3. Climax</source>
        <translation>3.高潮</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>3. Ending</source>
        <translation>3.结束</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Hero&apos;s journey</source>
        <translation>英雄旅程</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Ordinary world</source>
        <translation>平凡世界</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Call to adventure</source>
        <translation>冒险召唤</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Refusal of the call</source>
        <translation>拒绝召唤</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Meeting with mentor</source>
        <translation>遇见导师</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Tests</source>
        <translation>测试</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Approach</source>
        <translation>接近</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Abyss</source>
        <translation>深渊</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Reward / Revelation</source>
        <translation>奖励/启示</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Transformation</source>
        <translation>转变</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Atonement</source>
        <translation>赎罪</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Return</source>
        <translation>返回</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Hook</source>
        <translation>钩子</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Plot Turn 1</source>
        <translation>情节转折1</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Pinch 1</source>
        <translation>危急1</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Midpoint</source>
        <translation>中点</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Pinch 2</source>
        <translation>危急2</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Plot Turn 2</source>
        <translation>情节转折2</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Dan Wells 7-point plot format</source>
        <translation>七点情节结构</translation>
    </message>
</context>
<context>
    <name>plotModel</name>
    <message>
        <location filename="../manuskript/models/plotModel.py" line="145"/>
        <source>Name</source>
        <translation>名字</translation>
    </message>
    <message>
        <location filename="../manuskript/models/plotModel.py" line="147"/>
        <source>Meta</source>
        <translation>元</translation>
    </message>
    <message>
        <location filename="../manuskript/models/plotModel.py" line="180"/>
        <source>New step</source>
        <translation>新阶</translation>
    </message>
    <message>
        <location filename="../manuskript/models/plotModel.py" line="250"/>
        <source>Main</source>
        <translation>主要</translation>
    </message>
    <message>
        <location filename="../manuskript/models/plotModel.py" line="250"/>
        <source>Secondary</source>
        <translation>次要</translation>
    </message>
    <message>
        <location filename="../manuskript/models/plotModel.py" line="250"/>
        <source>Minor</source>
        <translation>轻微</translation>
    </message>
    <message>
        <location filename="../manuskript/models/plotModel.py" line="110"/>
        <source>New plot</source>
        <translation>新情节</translation>
    </message>
</context>
<context>
    <name>plotTreeView</name>
    <message>
        <location filename="../manuskript/ui/views/plotTreeView.py" line="131"/>
        <source>Main</source>
        <translation>主要</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotTreeView.py" line="131"/>
        <source>Secondary</source>
        <translation>次要</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotTreeView.py" line="131"/>
        <source>Minor</source>
        <translation>轻微</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotTreeView.py" line="191"/>
        <source>**Plot:** {}</source>
        <translation>**情节：**{}</translation>
    </message>
</context>
<context>
    <name>plotsProxyModel</name>
    <message>
        <location filename="../manuskript/models/plotsProxyModel.py" line="22"/>
        <source>Main</source>
        <translation>主要</translation>
    </message>
    <message>
        <location filename="../manuskript/models/plotsProxyModel.py" line="23"/>
        <source>Secondary</source>
        <translation>次要</translation>
    </message>
    <message>
        <location filename="../manuskript/models/plotsProxyModel.py" line="24"/>
        <source>Minors</source>
        <translation>轻微</translation>
    </message>
</context>
<context>
    <name>propertiesView</name>
    <message>
        <location filename="../manuskript/ui/views/propertiesView_ui.py" line="173"/>
        <source>Form</source>
        <translation>表格</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/propertiesView_ui.py" line="180"/>
        <source>POV</source>
        <translation>视角</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/propertiesView_ui.py" line="181"/>
        <source>Status</source>
        <translation>状态</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/propertiesView_ui.py" line="182"/>
        <source>Label</source>
        <translation>标签</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/propertiesView_ui.py" line="183"/>
        <source>Compile</source>
        <translation>编译</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/propertiesView_ui.py" line="184"/>
        <source>Goal</source>
        <translation>目标</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/propertiesView_ui.py" line="185"/>
        <source>Word count</source>
        <translation>词数</translation>
    </message>
</context>
<context>
    <name>revisions</name>
    <message>
        <location filename="../manuskript/ui/revisions_ui.py" line="86"/>
        <source>Form</source>
        <translation>表格</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions_ui.py" line="87"/>
        <source>Options</source>
        <translation>选项</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="257"/>
        <source>Restore</source>
        <translation>恢复</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="258"/>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="45"/>
        <source>Show modifications</source>
        <translation>显示修改</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="52"/>
        <source>Show ancient version</source>
        <translation>显示古版</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="60"/>
        <source>Show spaces</source>
        <translation>显示空格</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="66"/>
        <source>Show modifications only</source>
        <translation>仅示修改</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="110"/>
        <source>{} years ago</source>
        <translation>{}年前</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="112"/>
        <source>{} months ago</source>
        <translation>{}月前</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="114"/>
        <source>{} days ago</source>
        <translation>{}天前</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="116"/>
        <source>1 day ago</source>
        <translation>1天前</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="118"/>
        <source>{} hours ago</source>
        <translation>{}小时前</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="120"/>
        <source>{} minutes ago</source>
        <translation>{}分钟前</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="122"/>
        <source>{} seconds ago</source>
        <translation>{}秒前</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="182"/>
        <source>Line {}:</source>
        <translation>第{}行：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="261"/>
        <source>Clear all</source>
        <translation>全部清除</translation>
    </message>
</context>
<context>
    <name>search</name>
    <message>
        <location filename="../manuskript/ui/search_ui.py" line="47"/>
        <source>Form</source>
        <translation>表格</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/search_ui.py" line="48"/>
        <source>Search for...</source>
        <translation>查找…</translation>
    </message>
</context>
<context>
    <name>searchMenu</name>
    <message>
        <location filename="../manuskript/ui/searchMenu.py" line="31"/>
        <source>Case sensitive</source>
        <translation>区分大小写</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/searchMenu.py" line="32"/>
        <source>Match words</source>
        <translation>匹配词</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/searchMenu.py" line="33"/>
        <source>Regex</source>
        <translation>正则表达式</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/searchMenu.py" line="39"/>
        <source>Search in:</source>
        <translation>搜索于：</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/searchMenu.py" line="51"/>
        <source>Options:</source>
        <translation>选项：</translation>
    </message>
</context>
<context>
    <name>settingsWindow</name>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="688"/>
        <source>New status</source>
        <translation>新状态</translation>
    </message>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="709"/>
        <source>New label</source>
        <translation>新标签</translation>
    </message>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="745"/>
        <source>newtheme</source>
        <translation>新主题</translation>
    </message>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="755"/>
        <source>New theme</source>
        <translation>新主题</translation>
    </message>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="787"/>
        <source> (read-only)</source>
        <translation> （只读）</translation>
    </message>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="548"/>
        <source>Open Image</source>
        <translation>打开图像</translation>
    </message>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="564"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="561"/>
        <source>Unable to load selected file</source>
        <translation>无法加载所选文件</translation>
    </message>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="564"/>
        <source>Unable to add selected image:
{}</source>
        <translation>无法添加所选图像：
{}</translation>
    </message>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="548"/>
        <source>Image files</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>sldImportance</name>
    <message>
        <location filename="../manuskript/ui/views/sldImportance_ui.py" line="37"/>
        <source>Form</source>
        <translation>表格</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/sldImportance_ui.py" line="38"/>
        <source>TextLabel</source>
        <translation>文本标签</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/sldImportance.py" line="29"/>
        <source>Minor</source>
        <translation>轻微</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/sldImportance.py" line="30"/>
        <source>Secondary</source>
        <translation>次要</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/sldImportance.py" line="31"/>
        <source>Main</source>
        <translation>主要</translation>
    </message>
</context>
<context>
    <name>splitDialog</name>
    <message>
        <location filename="../manuskript/ui/tools/splitDialog.py" line="19"/>
        <source>
            &lt;p&gt;Split selected item(s) at the given mark.&lt;/p&gt;

            &lt;p&gt;If one of the selected item is a folder, it will be applied
            recursively to &lt;i&gt;all&lt;/i&gt; of it&apos;s children items.&lt;/p&gt;

            &lt;p&gt;The split mark can contain following escape sequences:
                &lt;ul&gt;
                    &lt;li&gt;&lt;b&gt;&lt;code&gt;\n&lt;/code&gt;&lt;/b&gt;: line break&lt;/li&gt;
                    &lt;li&gt;&lt;b&gt;&lt;code&gt;\t&lt;/code&gt;&lt;/b&gt;: tab&lt;/li&gt;
                &lt;/ul&gt;
            &lt;/p&gt;

            &lt;p&gt;&lt;b&gt;Mark:&lt;/b&gt;&lt;/p&gt;
            </source>
        <translation>
            &lt;p&gt;在指定的分割标记处分割所选中项目。&lt;/p&gt;

            &lt;p&gt;如果所选中的某项是文件夹，则分割将递归应用
            至其下的&lt;i&gt;各层&lt;/i&gt;子文件。&lt;/p&gt;

            &lt;p&gt;分割标记可以包含以下转义字符：
                &lt;ul&gt;
                    &lt;li&gt;&lt;b&gt;&lt;code&gt;\n&lt;/code&gt;&lt;/b&gt;：换行符&lt;/li&gt;
                    &lt;li&gt;&lt;b&gt;&lt;code&gt;\t&lt;/code&gt;&lt;/b&gt;：制表符&lt;/li&gt;
                &lt;/ul&gt;
            &lt;/p&gt;

            &lt;p&gt;&lt;b&gt;分割标记：&lt;/b&gt;&lt;/p&gt;
            </translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/splitDialog.py" line="47"/>
        <source>Split &apos;{}&apos;</source>
        <translation>分割“{}”</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/splitDialog.py" line="51"/>
        <source>Split items</source>
        <translation>分割项目</translation>
    </message>
</context>
<context>
    <name>storylineView</name>
    <message>
        <location filename="../manuskript/ui/views/storylineView_ui.py" line="58"/>
        <source>Form</source>
        <translation>表格</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/storylineView.py" line="36"/>
        <source>Show Plots</source>
        <translation>显示情节</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/storylineView.py" line="43"/>
        <source>Show Characters</source>
        <translation>显示人物</translation>
    </message>
</context>
<context>
    <name>tabSplitter</name>
    <message>
        <location filename="../manuskript/ui/editors/tabSplitter.py" line="68"/>
        <source>Open selected items in that view.</source>
        <translation>在该视图打开所选项。</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/tabSplitter.py" line="172"/>
        <source>Split horizontally</source>
        <translation>横分</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/tabSplitter.py" line="182"/>
        <source>Close split</source>
        <translation>关闭分割</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/tabSplitter.py" line="218"/>
        <source>Split vertically</source>
        <translation>纵分</translation>
    </message>
</context>
<context>
    <name>targets</name>
    <message>
        <location filename="../manuskript/ui/tools/targets_ui.py" line="131"/>
        <source>Project Targets</source>
        <translation>项目目标</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/targets_ui.py" line="132"/>
        <source>Draft Target</source>
        <translation>草稿目标</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/targets_ui.py" line="139"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/targets_ui.py" line="140"/>
        <source>of</source>
        <translation>含</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/targets_ui.py" line="135"/>
        <source>10,000</source>
        <translation>10,000</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/targets_ui.py" line="136"/>
        <source>Words</source>
        <translation>词</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/targets_ui.py" line="137"/>
        <source>Session Target</source>
        <translation>本节目标</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/targets_ui.py" line="138"/>
        <source>Reset</source>
        <translation>重置</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/targets_ui.py" line="141"/>
        <source>words</source>
        <translation>词</translation>
    </message>
</context>
<context>
    <name>textEditView</name>
    <message>
        <location filename="../manuskript/ui/views/textEditView.py" line="334"/>
        <source>Various</source>
        <translation>可变</translation>
    </message>
</context>
<context>
    <name>textFormat</name>
    <message>
        <location filename="../manuskript/ui/editors/textFormat_ui.py" line="90"/>
        <source>Form</source>
        <translation>表格</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/textFormat.py" line="18"/>
        <source>CTRL+B</source>
        <translation>CTRL+B</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/textFormat.py" line="19"/>
        <source>CTRL+I</source>
        <translation>CTRL+I</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/textFormat.py" line="20"/>
        <source>CTRL+U</source>
        <translation>CTRL+U</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/textFormat.py" line="21"/>
        <source>CTRL+P</source>
        <translation>CTRL+P</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/textFormat.py" line="22"/>
        <source>CTRL+L</source>
        <translation>CTRL+L</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/textFormat.py" line="23"/>
        <source>CTRL+E</source>
        <translation>CTRL+E</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/textFormat.py" line="24"/>
        <source>CTRL+R</source>
        <translation>CTRL+R</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/textFormat.py" line="25"/>
        <source>CTRL+J</source>
        <translation>CTRL+J</translation>
    </message>
</context>
<context>
    <name>treeView</name>
    <message>
        <location filename="../manuskript/ui/views/treeView.py" line="48"/>
        <source>Expand {}</source>
        <translation>展开{}</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/treeView.py" line="52"/>
        <source>Collapse {}</source>
        <translation>折叠{}</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/treeView.py" line="59"/>
        <source>Expand All</source>
        <translation>全部展开</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/treeView.py" line="63"/>
        <source>Collapse All</source>
        <translation>全部折叠</translation>
    </message>
</context>
<context>
    <name>welcome</name>
    <message>
        <location filename="../manuskript/ui/welcome_ui.py" line="126"/>
        <source>Form</source>
        <translation>表格</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome_ui.py" line="127"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome_ui.py" line="130"/>
        <source>Templates</source>
        <translation>模板</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome_ui.py" line="131"/>
        <source>Empty</source>
        <translation>空</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="225"/>
        <source>Novel</source>
        <translation>长篇小说</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="230"/>
        <source>Novella</source>
        <translation>中篇小说</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="235"/>
        <source>Short Story</source>
        <translation>短篇小说</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="247"/>
        <source>Research paper</source>
        <translation>研究论文</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="429"/>
        <source>Demo projects</source>
        <translation>示例项目</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome_ui.py" line="138"/>
        <source>Add level</source>
        <translation>增加层级</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome_ui.py" line="139"/>
        <source>Add word count</source>
        <translation>增加词数统计</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome_ui.py" line="140"/>
        <source>Next time, automatically open last project</source>
        <translation>下次自动打开最近项目</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome_ui.py" line="141"/>
        <source>Open...</source>
        <translation>打开…</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome_ui.py" line="142"/>
        <source>Recent</source>
        <translation>近期使用</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome_ui.py" line="143"/>
        <source>Create</source>
        <translation>创建</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="158"/>
        <source>Open project</source>
        <translation>打开项目</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="158"/>
        <source>Manuskript project (*.msk);;All files (*)</source>
        <translation>Manuskript项目(*.msk);;所有文件(*)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="172"/>
        <source>Save project as...</source>
        <translation>另存项目为…</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="196"/>
        <source>Manuskript project (*.msk)</source>
        <translation>Manuskript项目(*.msk)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="188"/>
        <source>Manuskript</source>
        <translation>Manuskript</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="196"/>
        <source>Create New Project</source>
        <translation>创建新项目</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="208"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="208"/>
        <source>Overwrite existing project {} ?</source>
        <translation>覆盖已有项目：{}？</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="224"/>
        <source>Empty fiction</source>
        <translation>空白虚构</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="459"/>
        <source>Chapter</source>
        <translation>章节</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="460"/>
        <source>Scene</source>
        <translation>场景</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="239"/>
        <source>Trilogy</source>
        <translation>分部小说</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="239"/>
        <source>Book</source>
        <translation>部</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="247"/>
        <source>Section</source>
        <translation>部分</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="246"/>
        <source>Empty non-fiction</source>
        <translation>空白纪实</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="309"/>
        <source>words each.</source>
        <translation>词每项。</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="312"/>
        <source>of</source>
        <translation>含</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="336"/>
        <source>Text</source>
        <translation>文本</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="339"/>
        <source>Something</source>
        <translation>某物</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="395"/>
        <source>&lt;b&gt;Total:&lt;/b&gt; {} words (~ {} pages)</source>
        <translation>&lt;b&gt;总计：&lt;/b&gt;{}词（～{}页）</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="416"/>
        <source>Fiction</source>
        <translation>虚构</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="422"/>
        <source>Non-fiction</source>
        <translation>纪实</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="457"/>
        <source>Idea</source>
        <translation>创意</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="458"/>
        <source>Note</source>
        <translation>笔记</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="461"/>
        <source>Research</source>
        <translation>研究</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="468"/>
        <source>TODO</source>
        <translation>待作</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="469"/>
        <source>First draft</source>
        <translation>初稿</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="470"/>
        <source>Second draft</source>
        <translation>次稿</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="471"/>
        <source>Final</source>
        <translation>终稿</translation>
    </message>
</context>
<context>
    <name>worldModel</name>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="136"/>
        <source>New item</source>
        <translation>新项目</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="251"/>
        <source>Fantasy world building</source>
        <translation>幻想世界构建</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="251"/>
        <source>Physical</source>
        <translation>物理</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="251"/>
        <source>Climate</source>
        <translation>气候</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="251"/>
        <source>Topography</source>
        <translation>地形</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="251"/>
        <source>Astronomy</source>
        <translation>天文</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="251"/>
        <source>Wild life</source>
        <translation>野生</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="251"/>
        <source>Flora</source>
        <translation>植被</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="251"/>
        <source>History</source>
        <translation>历史</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="251"/>
        <source>Races</source>
        <translation>种族</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="251"/>
        <source>Diseases</source>
        <translation>疾病</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Cultural</source>
        <translation>文化</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Customs</source>
        <translation>习俗</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Food</source>
        <translation>食物</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Languages</source>
        <translation>语言</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Education</source>
        <translation>教育</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Dresses</source>
        <translation>服饰</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Science</source>
        <translation>科学</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Calendar</source>
        <translation>历法</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Bodily language</source>
        <translation>体语</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Ethics</source>
        <translation>伦理</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Religion</source>
        <translation>宗教</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Government</source>
        <translation>政府</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Politics</source>
        <translation>政治</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Gender roles</source>
        <translation>性别</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Music and arts</source>
        <translation>艺术</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Architecture</source>
        <translation>建筑</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Military</source>
        <translation>军事</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Technology</source>
        <translation>科技</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Courtship</source>
        <translation>婚恋</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Demography</source>
        <translation>人口</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Transportation</source>
        <translation>交通</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Medicine</source>
        <translation>医药</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="285"/>
        <source>Magic system</source>
        <translation>魔法</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="285"/>
        <source>Rules</source>
        <translation>规则</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="285"/>
        <source>Organization</source>
        <translation>组织</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="285"/>
        <source>Magical objects</source>
        <translation>法器</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="285"/>
        <source>Magical places</source>
        <translation>魔境</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="285"/>
        <source>Magical races</source>
        <translation>魔族</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="292"/>
        <source>Important places</source>
        <translation>要地</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="293"/>
        <source>Important objects</source>
        <translation>要物</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="251"/>
        <source>Natural resources</source>
        <translation>物产</translation>
    </message>
</context>
</TS>
